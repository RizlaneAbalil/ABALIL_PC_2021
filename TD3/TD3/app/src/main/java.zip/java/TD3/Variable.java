package TD3;

public class Variable {

    public int val = 0;
}
